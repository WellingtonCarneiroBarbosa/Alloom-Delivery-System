<div class="preloader bg-soft flex-column justify-content-center align-items-center">
    <div class="loader-element">
        <span class="loader-animated-dot"></span>
        <img src="{{ asset('front/assets/img/brand/dark-loader.svg') }}" height="40" alt="Impact logo">
    </div>
</div>
