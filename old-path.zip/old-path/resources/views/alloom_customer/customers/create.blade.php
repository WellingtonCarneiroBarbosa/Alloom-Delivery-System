@extends('layouts.dash')

@section('title', 'Dashboard')

@section('nav-content')
    <x-alloom-customer.nav />
@endsection

@section('top-nav-content')
    <x-alloom-customer.top-nav />
@endsection


@section('footer-content')
    <x-alloom-customer.footer />
@endsection

@section('header-content')

@endsection


@section('main-content')

@endsection
