<?php

return [
    'status' => "Status alterado.",
    'created' => "cadastrado(a)",
];
