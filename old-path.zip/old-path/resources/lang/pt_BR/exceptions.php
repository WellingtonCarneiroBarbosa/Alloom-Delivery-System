<?php

return [
    'error' => "Não foi possível completar sua solicitação. Se o erro persistir, contate ao suporte.",
];
