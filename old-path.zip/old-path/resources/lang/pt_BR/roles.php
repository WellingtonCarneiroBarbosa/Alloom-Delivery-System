<?php

return [
    'alloom_user' => [
        'admin' => "Administrador"
    ],

    'alloom_customer_user' => [
        'manager' => "Gerente",
        'cooker' => "Cozinheiro(a)",
        'delivery_man' => "Entregador(a)",
        'clerk' => "Atendente",
    ],
];
