<?php

namespace App\Http\Controllers\AlloomDelivery\Users;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\AlloomDelivery\AlloomUser;

class AlloomUserController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\AlloomDelivery\AlloomUser  $alloomUser
     * @return \Illuminate\Http\Response
     */
    public function show(AlloomUser $alloomUser)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\AlloomDelivery\AlloomUser  $alloomUser
     * @return \Illuminate\Http\Response
     */
    public function edit(AlloomUser $alloomUser)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\AlloomDelivery\AlloomUser  $alloomUser
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, AlloomUser $alloomUser)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\AlloomDelivery\AlloomUser  $alloomUser
     * @return \Illuminate\Http\Response
     */
    public function destroy(AlloomUser $alloomUser)
    {
        //
    }
}
