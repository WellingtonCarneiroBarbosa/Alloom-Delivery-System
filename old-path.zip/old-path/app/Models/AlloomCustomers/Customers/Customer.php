<?php

namespace App\Models\AlloomCustomers\Customers;

use Illuminate\Database\Eloquent\Model;

class Customer extends Model
{
    //
}
